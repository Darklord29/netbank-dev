package com.dhanjyothi.dao;

import com.dhanjyothi.model.User;

public interface LoginDao {
	public int validateUser(User user);
}
