package com.dhanjyothi.service;

import com.dhanjyothi.model.User;



public interface LoginService {
	public int validateUser(User user);

}
