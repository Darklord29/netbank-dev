# netbank-dev

#Manager Login
user:adminmanager
pass:adminmanager

